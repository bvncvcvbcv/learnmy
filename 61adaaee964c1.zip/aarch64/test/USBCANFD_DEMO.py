'''
if there is no receive device(only usbcanfd) , the ZCAN_MSG_INFO "txm" use txtype --2, self test
if there is a same baudrate receive device ,  the ZCAN_MSG_INFO "txm" use txtype --0, normal send

ZLG  Zhiyuan Electronics
'''

from ctypes import *
import threading
import time
lib = cdll.LoadLibrary("./libusbcanfd.so")



ZCAN_DEVICE_TYPE  = c_uint32
ZCAN_DEVICE_INDEX = c_uint32
ZCAN_CHANNEL      = c_uint32
ZCAN_Reserved     = c_uint32
canfd_test        = 1
RES_ON            = 1  #Resistance setting
RES_OFF           = 0 
CAN_TRES          = 0x18 #Resistance address

USBCANFD_200U =   ZCAN_DEVICE_TYPE(33)
DEVICE_INDEX  =   ZCAN_DEVICE_INDEX(0)
CHANNEL_INDEX =   ZCAN_CHANNEL(0)
Reserved      =   ZCAN_Reserved(0)

def input_thread():
   input()

# can/canfd messgae info 
class ZCAN_MSG_INFO(Structure):
    _fields_=[("txm",c_uint,4), # TXTYPE:0 normal,1 once, 2self
              ("fmt",c_uint,4), # 0-can2.0 frame,  1-canfd frame
              ("sdf",c_uint,1), # 0-data frame, 1-remote frame
              ("sef",c_uint,1), # 0-std_frame, 1-ext_frame
              ("err",c_uint,1), # error flag
              ("brs",c_uint,1), # bit-rate switch ,0-Not speed up ,1-speed up
              ("est",c_uint,1), # error state 
              ("pad",c_uint,19)]


#CAN Message Header
class ZCAN_MSG_HDR(Structure):  
    _fields_=[("ts",c_uint32),  #timestamp
              ("id",c_uint32),  #can-id
              ("info",ZCAN_MSG_INFO),
              ("pad",c_uint16),
              ("chn",c_uint8),  #channel
              ("len",c_uint8)]  #data length

#CAN2.0-frame
class ZCAN_20_MSG(Structure):  
    _fields_=[("msg_header",ZCAN_MSG_HDR),
              ("dat",c_ubyte*8)]


#CANFD frame
class ZCAN_FD_MSG(Structure):  
    _fields_=[("msg_header",ZCAN_MSG_HDR),
               ("dat",c_ubyte*64)]




class abit_config(Structure):
    _fields_=[("tseg1",c_uint8),
              ("tseg2",c_uint8),
              ("sjw",c_uint8),
              ("smp",c_uint8),
              ("brp",c_uint16)]

class dbit_config(Structure):
    _fields_=[("tseg1",c_uint8),
              ("tseg2",c_uint8),
              ("sjw",c_uint8),
              ("smp",c_uint8),
              ("brp",c_uint16)]

class ZCANFD_INIT(Structure):
    _fields_=[("clk",c_uint32),
              ("mode",c_uint32),
              ("abit",abit_config),
              ("dbit",dbit_config)]

#Terminating resistor
class Resistance(Structure):
    _fields_=[("res",c_uint8)
              ]




def canfd_start(Devicetype,DeviceIndex,Channel):
    Res     = Resistance()
    Res.res = RES_ON
    lib.VCI_SetReference(Devicetype,DeviceIndex,Channel,CAN_TRES,byref(Res))
    canfd_init=ZCANFD_INIT()       #1M+1M
    canfd_init.clk         =   60000000
    canfd_init.mode        =   0
    canfd_init.abit.tseg1  =   7
    canfd_init.abit.tseg2  =   2
    canfd_init.abit.sjw    =   2
    canfd_init.abit.smp    =   0
    canfd_init.abit.brp    =   4
    canfd_init.dbit.tseg1  =   7
    canfd_init.dbit.tseg2  =   2
    canfd_init.dbit.sjw    =   2
    canfd_init.dbit.smp    =   0
    canfd_init.dbit.brp    =   4
    ret=lib.VCI_InitCAN(Devicetype,DeviceIndex,Channel,byref(canfd_init))
    if ret ==0:
        print("init Failed!")
    else:
        print("init success!")
    ret=lib.VCI_StartCAN(Devicetype,DeviceIndex,Channel)



def can_send(Devicetype,DeviceIndex,Channel):
    can_frame = (ZCAN_20_MSG*10)()
    for i in range(10):
        can_frame[i].msg_header.ts=0
        can_frame[i].msg_header.id=0x100+i
        can_frame[i].msg_header.info.txm = 2 #0--normal send, 2--self test
        can_frame[i].msg_header.info.fmt = 0 #can2.0
        can_frame[i].msg_header.info.sdf = 0 #data frame
        can_frame[i].msg_header.info.sef = 0 #std frame
        can_frame[i].msg_header.info.err = 0
        can_frame[i].msg_header.info.brs = 0
        can_frame[i].msg_header.info.est = 0
        can_frame[i].msg_header.pad      = 0
        can_frame[i].msg_header.chn      = 0
        can_frame[i].msg_header.len      = 8 
        for j in range (can_frame[i].msg_header.len):
            can_frame[i].dat[j]=j
    ret= lib.VCI_Transmit(Devicetype,DeviceIndex,Channel,byref(can_frame),10)
    print("Transmit num is:%d"%ret)


    if canfd_test:
        canfd_frame = (ZCAN_FD_MSG*10)()
        for i in range(10):
            canfd_frame[i].msg_header.ts=0
            canfd_frame[i].msg_header.id=0x100+i
            canfd_frame[i].msg_header.info.txm = 2 #0--normal send, 2--self test
            canfd_frame[i].msg_header.info.fmt = 1 #canFD
            canfd_frame[i].msg_header.info.sdf = 0 #data frame
            canfd_frame[i].msg_header.info.sef = 0 #std frame
            canfd_frame[i].msg_header.info.err = 0
            canfd_frame[i].msg_header.info.brs = 0
            canfd_frame[i].msg_header.info.est = 0
            canfd_frame[i].msg_header.pad      = 0
            canfd_frame[i].msg_header.chn      = 0
            canfd_frame[i].msg_header.len      = 32
            for j in range (canfd_frame[i].msg_header.len):
                canfd_frame[i].dat[j]=j
        ret= lib.VCI_TransmitFD(Devicetype,DeviceIndex,Channel,byref(canfd_frame),10)
    print("TransmitFD num is:%d"%ret)





if __name__=="__main__":
   ret=lib.VCI_OpenDevice(USBCANFD_200U,DEVICE_INDEX,Reserved)
   if ret ==0:
	    print("Opendevice fail!")
   else:
        print("Opendevice success!")
   canfd_start(USBCANFD_200U,DEVICE_INDEX,CHANNEL_INDEX)
   can_send(USBCANFD_200U,DEVICE_INDEX,CHANNEL_INDEX)
   thread=threading.Thread(target=input_thread)
   thread.start()
   channelfd = 0x80000000
   while True:
       time.sleep(0.1)
       ret  =  lib.VCI_GetReceiveNum(USBCANFD_200U,DEVICE_INDEX,CHANNEL_INDEX)
       ret1  =  lib.VCI_GetReceiveNum(USBCANFD_200U,DEVICE_INDEX,channelfd)
       if  ret:
           rcv_msgs  =(ZCAN_20_MSG*ret)()
           ret1     =lib.VCI_Receive(USBCANFD_200U,DEVICE_INDEX,CHANNEL_INDEX,byref(rcv_msgs),ret,100)
           for i in range(ret1):
                print("GetNum:%d, OrderNUM :%d,Timestamp:%d, id:%s , type: can ,dlc:%d ,data:%s"%(ret,i,(rcv_msgs[i].msg_header.ts),hex(rcv_msgs[i].msg_header.id),\
                      rcv_msgs[i].msg_header.len,''.join(hex(rcv_msgs[i].dat[j])+ ' 'for j in range(rcv_msgs[i].msg_header.len))))
       if  ret1:
           rcvfd_msgs  =(ZCAN_FD_MSG*ret1)()
           ret2     =lib.VCI_ReceiveFD(USBCANFD_200U,DEVICE_INDEX,CHANNEL_INDEX,byref(rcvfd_msgs),ret1,100)
           for i in range(ret2):
                print("GetNum:%d, OrderNUM :%d,Timestamp:%d, id:%s , type: canfd  ,brs:%d ,dlc:%d ,data:%s"%(ret2,i,(rcvfd_msgs[i].msg_header.ts),hex(rcvfd_msgs[i].msg_header.id),\
                       rcvfd_msgs[i].msg_header.info.brs,rcvfd_msgs[i].msg_header.len,''.join(hex(rcvfd_msgs[i].dat[j])+ ' 'for j in range(rcvfd_msgs[i].msg_header.len))))
       if thread.is_alive() == False:
            break

   
   
   ret=lib.VCI_ResetCAN(USBCANFD_200U,DEVICE_INDEX,CHANNEL_INDEX)
   if ret ==0:
        print("ResetCAN Failed!")
   else:
        print("ResetCAN success!")

   ret=lib.VCI_CloseDevice(USBCANFD_200U,DEVICE_INDEX)
   if ret ==0:
        print("Closedevice Failed!")
   else:
        print("Closedevice success!")
   print('done')
